
package modelo;

import java.io.Serializable;
import java.time.LocalDate;

/**
 *
 * @author lu
 */
public abstract class Evento implements Serializable{
    private int id;
    private String nombre;
    private LocalDate fecha;

    public Evento(int id, String nombre, LocalDate fecha) {
        this.id = id;
        this.nombre = nombre;
        this.fecha = fecha;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public String getNombre() {
        return nombre;
    }

    public int getId() {
        return id;
    }
    
    

    @Override
    public String toString() {
        return "Evento{" + "id=" + id + ", nombre=" + nombre + ", fecha=" + fecha + '}';
    }
    
    
    
    
}
