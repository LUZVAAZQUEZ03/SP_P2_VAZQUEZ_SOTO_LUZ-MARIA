
package modelo;

import java.io.Serializable;
import java.time.LocalDate;
import service.CSVSerializable;

/**
 *
 * @author lu
 */
public class EventoMusical extends Evento implements Serializable ,CSVSerializable, Comparable<EventoMusical>{
    
    private static final long serializacion = 1L;
    private String artista;
    private GeneroMusical genero;

    public EventoMusical(int id, String nombre, LocalDate fecha,String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }



    public GeneroMusical getGenero() {
        return genero;
    }
    
  

   
    @Override
    public String toSCV() {
        return super.getId() + "," + super.getNombre() + "," + super.getFecha() + "," + artista + "," + genero;
    }

    @Override
    public String toHeader() {
        return "id,nombre,fecha,artista,genero";
    }

    @Override
    public int compareTo(EventoMusical o) {
        return-1;
    }
    
    public static EventoMusical fromCSV(String eventos) {
        String[] partes = eventos.split(",");
        return new EventoMusical(
            Integer.parseInt(partes[0]),
            partes[1],
            LocalDate.parse(partes[2]),
            partes[3],
            GeneroMusical.valueOf(partes[4])
        );
    }

    
}
