
package modelo;

/**
 *
 * @author lu
 */
public enum GeneroMusical {
    
    ROCK, 
    JAZZ, 
    POP, 
    CLASICA,
    ELECTRONICA;
}
