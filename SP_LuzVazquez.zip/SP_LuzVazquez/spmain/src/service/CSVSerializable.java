
package service;

/**
 *
 * @author lu
 */
public interface CSVSerializable {
     String toSCV();
    
    String toHeader();
}
