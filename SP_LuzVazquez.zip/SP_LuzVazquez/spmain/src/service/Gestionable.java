
package service;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 *
 * @author lu
 * @param <T>
 */
public interface Gestionable<T extends CSVSerializable & Comparable<T>> {
    
    void agregar(T elemento);
    
    void eliminar (int index);
    
    T obtener (int index);
    
    void limpiarElementos();
    
    void ordenar(Comparator<T> comparator);
    
    void mostrarTodos();
    
    List<T> filtrar(Predicate<T> predicate);

    
    void guardarEnCSV(String path)throws IOException;
    
    void cargarDesdeCSV(String path, Function<String, T> transformadora)throws IOException;
    
    void cargarDesdeBinario(String path)throws IOException, ClassNotFoundException;
   
    void guardarEnBinario(String path)throws IOException;
    
}
