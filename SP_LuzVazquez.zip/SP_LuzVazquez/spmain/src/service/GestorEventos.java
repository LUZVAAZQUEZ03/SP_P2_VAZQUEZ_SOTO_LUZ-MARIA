
package service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import service.CSVSerializable;

/**
 *
 * @author lu
 * @param <T>
 */
public class GestorEventos <T extends CSVSerializable & Comparable<T>> implements Gestionable<T> {
    private List<T> lista = new ArrayList<>();

    @Override
    public void agregar(T elemento) {
       if(elemento == null){
            throw new IllegalArgumentException("No se pueden agregar elementos vacios!");
        }lista.add(elemento);
    }

    private boolean verificarlLista(int index){
        if (lista.isEmpty()){
            throw new NullPointerException("La lista esta vacia");
        }
        return lista.size() >= index;
    }
    
    @Override
    public void eliminar(int index) {
       if(!verificarlLista(index)){        
            throw new IllegalArgumentException("El indice ingresado excede los items existentes!");
            }
        lista.remove(index);
    }
    

    @Override
    public T obtener(int index) {
        if(!verificarlLista(index)){        
            throw new IllegalArgumentException("El indice ingresado excede los items existentes!");
            }
        return lista.get(index);
    }

    @Override
    public void limpiarElementos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    @Override
    public void ordenar(Comparator<T> comparator) {
        lista.sort(comparator);
    }

    @Override
    public void mostrarTodos() {
       if (lista.isEmpty()){
           throw new RuntimeException("la lista esta vacia");
       }
       for (T elemento : lista){
           System.out.println(elemento);
       }
    }

    @Override
    public List<T> filtrar(Predicate<T> predicate) {
        List<T> toReturn = new ArrayList<>();
        for(T elemento : lista){
            if (predicate.test(elemento)){
                toReturn.add(elemento);
            }
        }
        return toReturn;
    }
 
       @Override
    public void guardarEnCSV(String path) throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter(path));
        bw.write(lista.get(0).toHeader() + "\n");
        for(T elemento: lista){
            bw.write(elemento.toSCV() + "\n");
        }
        bw.close();
    }
    
    @Override
    public void cargarDesdeCSV(String path, Function<String, T> transformadora) throws IOException {
        lista.clear();
        BufferedReader br = new BufferedReader(new FileReader(path));
        String linea = "";
        br.readLine();
        while ((linea = br.readLine()) != null){
            lista.add(transformadora.apply(linea));
            
        }
        br.close(); 
    }
    



    @Override
    public void guardarEnBinario(String path) throws IOException {
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path));
        salida.writeObject(lista);
        salida.close();
    }

    @Override
    public void cargarDesdeBinario(String path) throws IOException, ClassNotFoundException {
        lista.clear();
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path));

        lista.addAll((List<T>) entrada.readObject());

        entrada.close();  
    }
}
