
package Config;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *
 * @author lu
 */
public class AppConfig {
  
    public static final Path PATH_SER = Paths.get("src/data/eventos.dat");

    public static final Path PATH_CSV = Paths.get("src/data/eventos.csv");
    
    
}
